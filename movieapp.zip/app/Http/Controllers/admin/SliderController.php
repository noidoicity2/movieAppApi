<?php

namespace App\Http\Controllers\admin;

class SliderController
{

}
