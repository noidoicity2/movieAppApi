<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Movie\\Providers\\MovieServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Movie\\Providers\\MovieServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);